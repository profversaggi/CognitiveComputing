# SoarProgrammersGuide
A practical, cookbook-style guide to common Soar patterns. 

Get started here: http://soartech.github.io/SoarProgrammersGuide/31654126.html