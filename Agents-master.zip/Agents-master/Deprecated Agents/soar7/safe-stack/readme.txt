
ReadMe
of the Safe-To-Stack Soar System
Jan 3, 94


This directory contains:

  --  (a) README, this file;
  --  (b) safe-to-stack.soar, the Soar system which runs with Soar 7.0.3; and
  --  (c) probs, a directory of various problems to solve from the domain of (b).

For the task domain, see the header of the file (b).

When first loaded, (b) attempts to solve prob.1 (see the directory probs).

To try another problem, just source a prob file from the directory probs and
do init-soar. 

